﻿using Xamarin.Forms;

namespace Laavor
{
    namespace Inquiry
    {
        public class SwitchContentItem : StackLayout
        {
            public SwitchContentItem()
            {
             //   this.IsVisible = false;
            }
        }
    }
}
