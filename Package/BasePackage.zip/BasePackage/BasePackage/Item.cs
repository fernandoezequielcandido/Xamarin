﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasePackage
{
    public class Item
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string NameChosen { get; set; }
        public string Value { get; set; }
        public int Year { get; set; }
    }
}
