﻿namespace Laavor
{
    namespace Group
    {
        /// <summary>
        /// GroupBoxAll
        /// </summary>
        public class GroupBoxAll
        {
            /// <summary>
            /// barBox as Image
            /// </summary>
            public GroupBoxControl barControl { get; set; }

            /// <summary>
            /// barTitle as Label
            /// </summary>
            public GroupBoxTitle barTitle { get; set; }
        }
    }
}
