﻿using Xamarin.Forms;

namespace Laavor
{
    namespace Group
    {
        /// <summary>
        /// Class GroupBarTitle
        /// </summary>
        public class GroupBoxTitle : Label
        {
            /// <summary>
            /// Constructor of GroupBoxTitle
            /// </summary>
            public GroupBoxTitle() : base()
            {

            }
        }
    }
}
