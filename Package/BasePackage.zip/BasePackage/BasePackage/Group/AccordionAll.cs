﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Laavor
{
    namespace Group
    {
        /// <summary>
        /// Class AccordionAll
        /// </summary>
        public class AccordionAll
        {
            /// <summary>
            /// barAccordion as Image
            /// </summary>
            public GroupBoxControl barAccordion { get; set; }

            /// <summary>
            /// barTitel as Label
            /// </summary>
            public AccordionTitle barTitle { get; set; }
        }
    }
}
